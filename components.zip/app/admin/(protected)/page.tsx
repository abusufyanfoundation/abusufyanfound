import Link from "next/link";
import { ProgressBar } from "@/components/ui/ProgressBar";
import {
  EmptyState,
  PageHeader,
  Panel,
  Stat,
  StatGrid,
  StatusText,
  TableWrap,
  td,
  th,
} from "@/components/admin/ui";
import { requireAdmin } from "@/lib/auth/require-admin";
import { formatDateTime } from "@/lib/format";
import { formatNaira } from "@/lib/money";
import { createClient } from "@/lib/supabase/server";
import { loadGivenTo } from "@/lib/admin/donation-targets";

export const metadata = {
  title: "Overview",
  robots: { index: false, follow: false },
};

type Overview = {
  total_raised_kobo: number;
  paid_donations: number;
  books_listed: number;
  books_distributed: number;
  to_fulfil: number;
  completed_batches: number;
  active_campaigns: number;
  pending_applications: number;
  approved_applications: number;
  pending_requests: number;
};

type RecentDonation = {
  id: string;
  created_at: string;
  type: "general" | "book";
  donor_name: string;
  amount_kobo: number;
  is_paid: boolean;
  campaign_id: string | null;
  batch_id: string | null;
};

type Activity = {
  id: string;
  created_at: string;
  actor_name: string | null;
  actor_email: string | null;
  summary: string;
};

export default async function AdminOverviewPage() {
  await requireAdmin();
  const supabase = await createClient();

  const [overview, campaignRes, donations, activity] = await Promise.all([
    supabase.from("admin_overview").select("*").single<Overview>(),
    supabase
      .from("campaigns")
      .select("id, title, target_kobo, campaign_type")
      .eq("is_active", true)
      .order("campaign_type", { ascending: false })
      .returns<
        {
          id: string;
          title: string;
          target_kobo: number;
          campaign_type: string;
        }[]
      >(),
    supabase
      .from("donations")
      .select(
        "id, created_at, type, donor_name, amount_kobo, is_paid, campaign_id, batch_id",
      )
      .order("created_at", { ascending: false })
      .limit(8)
      .returns<RecentDonation[]>(),
    supabase
      .from("audit_log")
      .select("id, created_at, actor_name, actor_email, summary")
      .order("created_at", { ascending: false })
      .limit(8)
      .returns<Activity[]>(),
  ]);

  const givenTo = await loadGivenTo(supabase, donations.data ?? []);
  
  const campaigns = campaignRes.data ?? [];

  const generalIds = campaigns
    .filter((c) => c.campaign_type !== "batch")
    .map((c) => c.id);
  const generalTotals = generalIds.length
    ? ((
        await supabase
          .from("admin_campaign_totals")
          .select("campaign_id, raised_kobo")
          .in("campaign_id", generalIds)
          .returns<{ campaign_id: string; raised_kobo: number }[]>()
      ).data ?? [])
    : [];
  const generalRaised = new Map(
    generalTotals.map((t) => [t.campaign_id, t.raised_kobo]),
  );

  // A batch-based campaign shows the batch that is taking donations
  const batchCampaignIds = campaigns
    .filter((c) => c.campaign_type === "batch")
    .map((c) => c.id);
  const collectingBy = new Map<
    string,
    { number: number; title: string; target: number; raised: number }
  >();

  if (batchCampaignIds.length) {
    const { data: drafts } = await supabase
      .from("batches")
      .select("id, campaign_id, batch_number, title, target_kobo")
      .in("campaign_id", batchCampaignIds)
      .eq("status", "draft")
      .order("batch_number")
      .returns<
        {
          id: string;
          campaign_id: string;
          batch_number: number;
          title: string;
          target_kobo: number;
        }[]
      >();

    const { data: rows } = await supabase
      .from("admin_batch_totals")
      .select("batch_id, raised_kobo")
      .in(
        "batch_id",
        (drafts ?? []).map((b) => b.id),
      )
      .returns<{ batch_id: string; raised_kobo: number }[]>();

    const raisedBy = new Map(
      (rows ?? []).map((r) => [r.batch_id, r.raised_kobo]),
    );
    for (const b of drafts ?? []) {
      const raised = raisedBy.get(b.id) ?? 0;
      if (collectingBy.has(b.campaign_id) || raised >= b.target_kobo) continue;
      collectingBy.set(b.campaign_id, {
        number: b.batch_number,
        title: b.title,
        target: b.target_kobo,
        raised,
      });
    }
  }

  const o = overview.data;
  return (
    <div className="flex flex-col gap-10">
      <PageHeader
        title="Overview"
        intro="What needs your attention, how the campaigns are doing, and the totals so far."
      />

      {overview.error && (
        <p
          role="alert"
          className="border-l-2 border-red-700 bg-red-50 px-4 py-3 text-sm text-red-800"
        >
          The overview figures could not be loaded. Check that the latest SQL
          has been run.
        </p>
      )}

      <section>
        <h2 className="mb-4 font-display text-xl text-navy">
          Needs your attention
        </h2>
        <StatGrid>
          <Stat
            label="Applications to review"
            value={String(o?.pending_applications ?? 0)}
          />
          <Stat
            label="Approved, not yet given out"
            value={String(o?.approved_applications ?? 0)}
          />
          <Stat
            label="Book requests to review"
            value={String(o?.pending_requests ?? 0)}
          />
          <Stat label="Orders to fulfil" value={String(o?.to_fulfil ?? 0)} />
        </StatGrid>
      </section>

      <section>
        <h2 className="mb-4 font-display text-xl text-navy">Overall</h2>
        <StatGrid>
          <Stat
            label="Total raised"
            value={formatNaira(o?.total_raised_kobo ?? 0)}
          />
          <Stat
            label="Books distributed"
            value={String(o?.books_distributed ?? 0)}
          />
          <Stat
            label="Completed batches"
            value={String(o?.completed_batches ?? 0)}
          />
        </StatGrid>
      </section>

      <Panel
        title={campaigns.length > 1 ? "Current campaigns" : "Current campaign"}
      >
        {campaigns.length > 0 ? (
          <div className="flex flex-col gap-8">
            {campaigns.map((c) => {
              const isBatch = c.campaign_type === "batch";
              const collecting = collectingBy.get(c.id);
              const raised = isBatch
                ? (collecting?.raised ?? 0)
                : (generalRaised.get(c.id) ?? 0);
              const target = isBatch
                ? (collecting?.target ?? 0)
                : c.target_kobo;
              return (
                <div key={c.id}>
                  <p className="font-display text-2xl text-navy">{c.title}</p>
                  {isBatch && (
                    <p className="mt-1 text-sm text-muted">
                      {collecting
                        ? `Batch ${collecting.number}: ${collecting.title}`
                        : "No batch is taking donations right now."}
                    </p>
                  )}
                  {(!isBatch || collecting) && (
                    <>
                      <div className="mt-4">
                        <ProgressBar raisedKobo={raised} targetKobo={target} />
                      </div>
                      <p className="mt-1 text-sm text-muted">
                        {formatNaira(raised)} of {formatNaira(target)}
                      </p>
                    </>
                  )}
                  {isBatch && !collecting && (
                    <Link
                      href={`/admin/batches/new?campaign=${c.id}`}
                      className="mt-4 inline-block text-sm text-navy underline decoration-gold underline-offset-4"
                    >
                      Create the next batch
                    </Link>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <EmptyState
            title="No active campaign"
            text="Create a campaign or activate an existing one to show it on the website."
            action={{ label: "Go to campaigns", href: "/admin/campaigns" }}
          />
        )}
      </Panel>

      <section>
        <h2 className="mb-4 font-display text-xl text-navy">
          Recent donations
        </h2>
        {donations.data && donations.data.length > 0 ? (
          <TableWrap>
            <thead className="border-b border-rule bg-paper">
              <tr>
                <th className={th}>Date</th>
                <th className={th}>Donor</th>
                <th className={th}>Type</th>
                <th className={th}>Given to</th>
                <th className={th}>Amount</th>
                <th className={th}>Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-rule">
              {donations.data.map((d) => (
                <tr key={d.id}>
                  <td className={td}>{formatDateTime(d.created_at)}</td>
                  <td className={td}>{d.donor_name}</td>
                  <td className={td}>
                    {d.type === "book" ? "Book pre-fund" : "Campaign"}
                  </td>
                  <td className={td}>
                    <p>{givenTo.get(d.id)?.name}</p>
                    {givenTo.get(d.id)?.batch != null && (
                      <p className="mt-1 text-xs text-muted">
                        Batch {givenTo.get(d.id)?.batch}
                      </p>
                    )}
                  </td>
                  <td className={td}>{formatNaira(d.amount_kobo)}</td>
                  <td className={td}>
                    <StatusText status={d.is_paid ? "Paid" : "Pending"} />
                  </td>
                </tr>
              ))}
            </tbody>
          </TableWrap>
        ) : (
          <EmptyState
            title="No donations yet"
            text="Donations will appear here as soon as the first one is made."
          />
        )}
      </section>

      <section>
        <div className="mb-4 flex items-baseline justify-between gap-4">
          <h2 className="font-display text-xl text-navy">Recent activity</h2>
          <Link
            href="/admin/activity"
            className="text-sm text-navy underline decoration-gold underline-offset-4"
          >
            View all activity
          </Link>
        </div>
        {activity.data && activity.data.length > 0 ? (
          <TableWrap>
            <thead className="border-b border-rule bg-paper">
              <tr>
                <th className={th}>When</th>
                <th className={th}>Admin</th>
                <th className={th}>What happened</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-rule">
              {activity.data.map((a) => (
                <tr key={a.id}>
                  <td className={td}>{formatDateTime(a.created_at)}</td>
                  <td className={td}>
                    {a.actor_name ?? a.actor_email ?? "Unknown"}
                  </td>
                  <td className={td}>{a.summary}</td>
                </tr>
              ))}
            </tbody>
          </TableWrap>
        ) : (
          <EmptyState
            title="No activity yet"
            text="What admins do (creating campaigns, editing books, signing in) is recorded here."
          />
        )}
      </section>
    </div>
  );
}
