import { revalidatePath } from "next/cache";
import { notFound } from "next/navigation";
import { FormMessage } from "@/components/admin/auth/FormMessage";
import {
  EmptyState,
  PageHeader,
  Panel,
  TableWrap,
  td,
  th,
} from "@/components/admin/ui";
import { logAudit } from "@/lib/admin/audit";
import { flash } from "@/lib/admin/flash";
import { requireAdmin } from "@/lib/auth/require-admin";
import { formatDateTime } from "@/lib/format";
import { createClient } from "@/lib/supabase/server";

export const metadata = {
  title: "Distributions",
  robots: { index: false, follow: false },
};

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function recordDistribution(formData: FormData) {
  "use server";

  const actor = await requireAdmin();

  const campaignId = String(formData.get("campaign_id") ?? "");
  const beneficiaryId = String(formData.get("beneficiary_id") ?? "");
  // "batch:<uuid>" for a batch book, "book:<uuid>" for a catalogue book
  const [kind, bookId] = String(formData.get("book") ?? "").split(":");
  const quantity = Number(formData.get("quantity"));
  const notes = String(formData.get("notes") ?? "").trim();

  if (!UUID.test(campaignId)) {
    return flash("/admin/campaigns", "error", "Campaign not found.");
  }

  const path = `/admin/campaigns/${campaignId}/distributions`;
  const fail = (message: string): never => flash(path, "error", message);

  if (!UUID.test(beneficiaryId)) return fail("Please choose a beneficiary.");
  if (!UUID.test(bookId ?? "") || (kind !== "batch" && kind !== "book")) {
    return fail("Please choose a book.");
  }
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 100000) {
    return fail("Quantity must be a whole number of at least 1.");
  }

  const supabase = await createClient();

  const { data: distribution, error } = await supabase
    .from("distributions")
    .insert({
      campaign_id: campaignId,
      beneficiary_id: beneficiaryId,
      notes: notes || null,
      recorded_by: actor.user.id,
    })
    .select("id")
    .single<{ id: string }>();

  if (error || !distribution) {
    console.error("recordDistribution:", error?.message);
    return fail("The distribution could not be recorded.");
  }

  const { error: itemError } = await supabase
    .from("distribution_items")
    .insert({
      distribution_id: distribution.id,
      quantity,
      ...(kind === "batch" ? { batch_book_id: bookId } : { book_id: bookId }),
    });

  if (itemError) {
    console.error("recordDistribution item:", itemError.message);

    // do not leave an empty distribution behind
    await supabase.from("distributions").delete().eq("id", distribution.id);

    return fail("The distribution could not be recorded.");
  }

  await logAudit(supabase, actor, {
    action: "distribution.created",
    entity: "campaign",
    entityId: campaignId,
    summary: `Recorded distribution of ${quantity} book(s)`,
    details: {
      campaign_id: campaignId,
      beneficiary_id: beneficiaryId,
      [kind === "batch" ? "batch_book_id" : "book_id"]: bookId,
      quantity,
    },
  });

  revalidatePath(`/admin/campaigns/${campaignId}`);
  revalidatePath(path);
  revalidatePath("/admin");
  revalidatePath("/admin/activity");
  return flash(path, "notice", "Distribution recorded.");
}

type DistributionRow = {
  id: string;
  distributed_at: string;
  notes: string | null;
  beneficiary: { name: string; type: string } | null;
  distribution_items: {
    quantity: number;
    book: { title: string } | null;
    batch_book: { title: string } | null;
  }[];
};

type Option = {
  id: string;
  name?: string;
  title?: string;
};

export default async function DistributionsPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string; notice?: string }>;
}) {
  const { id } = await params;
  const { error, notice } = await searchParams;

  await requireAdmin();

  if (!UUID.test(id)) notFound();

  const supabase = await createClient();

  const [campaign, beneficiaries, books, batchBooks, distributions] =
    await Promise.all([
      supabase
        .from("campaigns")
        .select("id, title")
        .eq("id", id)
        .maybeSingle<{ id: string; title: string }>(),

      supabase
        .from("beneficiaries")
        .select("id, name")
        .order("name")
        .returns<Option[]>(),

      supabase
        .from("books")
        .select("id, title")
        .order("title")
        .returns<Option[]>(),

      supabase
        .from("batch_books")
        .select("id, title, batches!inner(campaign_id)")
        .eq("batches.campaign_id", id)
        .order("title")
        .returns<Option[]>(),

      supabase
        .from("distributions")
        .select(
          `id, distributed_at, notes,
           beneficiary:beneficiaries(name, type),
           distribution_items(
             quantity,
             book:books(title),
             batch_book:batch_books(title)
           )`,
        )
        .eq("campaign_id", id)
        .order("distributed_at", { ascending: false })
        .returns<DistributionRow[]>(),
    ]);

  if (!campaign.data) notFound();

  return (
    <div className="flex flex-col gap-8">
      <PageHeader
        title="Campaign distributions"
        intro={`Record books purchased with funds from "${campaign.data.title}" and where they went.`}
        back={{ label: "Back to campaign", href: `/admin/campaigns/${id}` }}
      />

      {error && <FormMessage error={error} />}
      {notice && <FormMessage message={notice} />}

      <Panel title="Record distribution">
        <form action={recordDistribution} className="grid gap-4 md:grid-cols-2">
          <input type="hidden" name="campaign_id" value={id} />

          <label className="text-sm text-muted">
            Beneficiary
            <select
              required
              name="beneficiary_id"
              className="mt-1 w-full border border-rule bg-white px-3 py-2 text-sm text-ink"
            >
              <option value="">Select beneficiary</option>
              {(beneficiaries.data ?? []).map((beneficiary) => (
                <option key={beneficiary.id} value={beneficiary.id}>
                  {beneficiary.name}
                </option>
              ))}
            </select>
          </label>

          <label className="text-sm text-muted">
            Book
            <select
              required
              name="book"
              className="mt-1 w-full border border-rule bg-white px-3 py-2 text-sm text-ink"
            >
              <option value="">Select book</option>

              {(batchBooks.data ?? []).length > 0 && (
                <optgroup label="Books in this campaign's batches">
                  {(batchBooks.data ?? []).map((book) => (
                    <option key={book.id} value={`batch:${book.id}`}>
                      {book.title}
                    </option>
                  ))}
                </optgroup>
              )}

              <optgroup label="Catalogue books">
                {(books.data ?? []).map((book) => (
                  <option key={book.id} value={`book:${book.id}`}>
                    {book.title}
                  </option>
                ))}
              </optgroup>
            </select>
          </label>

          <label className="text-sm text-muted">
            Quantity
            <input
              required
              min={1}
              type="number"
              name="quantity"
              className="mt-1 w-full border border-rule px-3 py-2 text-sm text-ink"
            />
          </label>

          <label className="text-sm text-muted">
            Notes
            <textarea
              name="notes"
              rows={3}
              className="mt-1 w-full border border-rule px-3 py-2 text-sm text-ink"
            />
          </label>

          <button
            type="submit"
            className="w-fit bg-navy px-5 py-2 text-sm font-medium text-white hover:bg-navy-deep md:col-span-2"
          >
            Record distribution
          </button>
        </form>
      </Panel>

      {distributions.data?.length ? (
        <TableWrap>
          <thead className="border-b border-rule bg-paper">
            <tr>
              <th className={th}>Date</th>
              <th className={th}>Beneficiary</th>
              <th className={th}>Books</th>
              <th className={th}>Notes</th>
            </tr>
          </thead>

          <tbody className="divide-y divide-rule">
            {distributions.data.map((distribution) => (
              <tr key={distribution.id}>
                <td className={td}>
                  {formatDateTime(distribution.distributed_at)}
                </td>
                <td className={td}>
                  {distribution.beneficiary?.name ?? "Unknown beneficiary"}
                </td>
                <td className={td}>
                  {distribution.distribution_items.map((item, index) => (
                    <div key={index}>
                      {item.quantity} ×{" "}
                      {item.batch_book?.title ??
                        item.book?.title ??
                        "Unknown book"}
                    </div>
                  ))}
                </td>
                <td className={td}>{distribution.notes ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </TableWrap>
      ) : (
        <EmptyState
          title="No distributions yet"
          text="Recorded distributions for this campaign will appear here."
        />
      )}
    </div>
  );
}
