import { z } from "zod";

// Accepts0801 234 5678, +234 801 234 5678 and 2348012345678, and stores +2348164758649
export function normalisePhone(raw: string): string | null {
  const digits = raw.replace(/[^\d+]/g, "");
  if (/^\+234\d{10}$/.test(digits)) return digits;
  if (/^234\d{10}$/.test(digits)) return `+${digits}`;
  if (/^0\d{10}$/.test(digits)) return `+234${digits.slice(1)}`;
  return null;
}

const phone = z
  .string()
  .trim()
  .refine(
    (v) => normalisePhone(v) !== null,
    "Please enter a valid Nigerian phone number, for example 0801 234 5678",
  )
  .transform((v) => normalisePhone(v) as string);

// Optional for individuals. Normalised when given, and "" marks a number that is not valid.
const optionalPhone = z
  .string()
  .trim()
  .optional()
  .transform((v) => (v ? (normalisePhone(v) ?? "") : undefined));

const required = (what: string, min = 2, max = 200) =>
  z.string().trim().min(min, `Please enter ${what}`).max(max);

const applicantType = z.enum(["individual", "mosque", "school"], {
  error: "Please choose who is applying",
});

const contact = {
  applicantType,
  organisationName: z.string().trim().max(200).optional(),
  phone,
  email: z
    .string()
    .trim()
    .min(1, "Please enter your email address")
    .email("Please enter a valid email address"),
  state: required("your state", 2, 80),
  city: required("your city or town", 2, 80),
  address: required("your address", 5, 300),
};

const needsOrganisation = (
  v: { applicantType: string; organisationName?: string },
  ctx: z.RefinementCtx,
) => {
  if (v.applicantType !== "individual" && !v.organisationName) {
    ctx.addIssue({
      code: "custom",
      path: ["organisationName"],
      message:
        v.applicantType === "mosque"
          ? "Please enter the name of the mosque"
          : "Please enter the name of the school",
    });
  }
};

export const applicationSchema = z
  .object({
    batchId: z.string().uuid(),
    ...contact,
    applicantName: required("your full name", 2, 120),
    verifierName: z.string().trim().max(120).optional(),
    verifierRole: z.string().trim().max(120).optional(),
    verifierPhone: optionalPhone,
    fulfilmentMethod: z.enum(["pickup", "delivery"], {
      error: "Please choose how you will receive the books",
    }),
    reason: required("why you need this book", 5, 1000),
    locationId: z.string().uuid().optional(),
    items: z
      .array(
        z.object({
          batchBookId: z.string().uuid(),
          quantity: z
            .number({ error: "Please enter how many copies you need" })
            .int("Please enter a whole number of copies")
            .min(1, "Please enter at least one copy")
            .max(100),
        }),
      )
      .min(1, "Please choose the book you are applying for")
      .max(2, "You can apply for at most two books in each batch"),
  })
  .superRefine(needsOrganisation)
  .superRefine((v, ctx) => {
    if (v.fulfilmentMethod === "delivery" && v.applicantType === "individual") {
      ctx.addIssue({
        code: "custom",
        path: ["fulfilmentMethod"],
        message: "Individuals collect their books in person",
      });
    }
    if (v.fulfilmentMethod === "pickup" && !v.locationId) {
      ctx.addIssue({
        code: "custom",
        path: ["locationId"],
        message: "Please choose where you will collect your books",
      });
    }

    if (v.applicantType === "individual" && v.items.length > 1) {
      ctx.addIssue({
        code: "custom",
        path: ["items"],
        message: "Individuals can apply for only one book in each batch",
      });
    }
    if (new Set(v.items.map((i) => i.batchBookId)).size !== v.items.length) {
      ctx.addIssue({
        code: "custom",
        path: ["items"],
        message: "Please choose two different books",
      });
    }

    // Mosques and schools need a reference person. Individuals do not.
    if (v.applicantType !== "individual") {
      if (!v.verifierName) {
        ctx.addIssue({
          code: "custom",
          path: ["verifierName"],
          message: "Please enter your reference person's name",
        });
      }
      if (!v.verifierRole) {
        ctx.addIssue({
          code: "custom",
          path: ["verifierRole"],
          message:
            "Please enter your reference person's position or relationship",
        });
      }
      if (!v.verifierPhone) {
        ctx.addIssue({
          code: "custom",
          path: ["verifierPhone"],
          message:
            "Please enter a valid Nigerian phone number for your reference person",
        });
      } else if (v.verifierPhone === v.phone) {
        ctx.addIssue({
          code: "custom",
          path: ["verifierPhone"],
          message:
            "Your reference person's phone number must be different from yours",
        });
      }
    }
  });

export const bookRequestSchema = z
  .object({
    ...contact,
    requesterName: required("your full name", 2, 120),
    bookTitle: required("the book's title"),
    bookAuthor: required("the author's name", 2, 200),
    quantity: z
      .number({ error: "Please enter how many copies you need" })
      .int("Please enter a whole number")
      .min(1, "Please enter how many copies you need")
      .max(50, "Schools can request up to 50 copies"),
    reason: required("why you need this book", 5, 1000),
  })
  .superRefine(needsOrganisation)
  .superRefine((v, ctx) => {
    if (v.applicantType !== "school" && v.quantity > 1) {
      ctx.addIssue({
        code: "custom",
        path: ["quantity"],
        message: "Individuals and mosques can request 1 copy",
      });
    }
  });
